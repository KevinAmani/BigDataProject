## For users who want to report an issue
Please read [this wiki page]
(https://github.com/dnschneid/crouton/wiki/Common-issues-and-reporting)
for instructions on reporting an issue.

## For contributors
Please read [this
section](https://github.com/dnschneid/crouton#i-want-to-be-a-contributor)
of the README and the following relevant sections first.
